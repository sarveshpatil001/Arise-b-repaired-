// ARISE V1 — ACCOUNT / ADMIN AUTHORIZATION regression tests (PRD Step 4).
// These run the REAL Convex functions against an in-memory backend, so they
// exercise server-side guards rather than UI routing:
//   - unauthenticated callers cannot read or write another user's data,
//   - cross-user access is denied by the handlers, not by hidden buttons,
//   - admin-only operations require the admin role on the server,
//   - the first-admin bootstrap can be claimed exactly once, even concurrently,
//   - the authenticated market-data action validates every input before it
//     reaches a provider.
// No live market data, no network, no real orders.

import { convexTest } from "convex-test";
import { afterEach, describe, expect, it } from "vitest";
import schema from "@/convex/schema";
import { api } from "@/convex/_generated/api";

// The glob must include src/convex/_generated — convex-test derives the module
// root from it. (Test files live outside src/convex so the Convex bundler never
// picks them up.)
const modules = import.meta.glob("../../convex/**/*.ts");

type TestConvex = ReturnType<typeof convexTest>;

function newBackend() {
  return convexTest(schema, modules);
}

async function seedUser(
  t: TestConvex,
  opts: { email: string; role?: "admin" | "user"; disabled?: boolean } = { email: "u@example.com" },
) {
  return await t.run(async (ctx) =>
    ctx.db.insert("users", {
      email: opts.email,
      role: opts.role,
      disabled: opts.disabled,
    }),
  );
}

afterEach(() => {
  delete process.env.ARISE_ADMIN_CODE;
});

describe("unauthenticated access", () => {
  it("cannot create or mutate an account", async () => {
    const t = newBackend();
    await expect(t.mutation(api.arise.trading.createAccount, {})).rejects.toThrow(/Not authenticated/);
    await expect(t.mutation(api.arise.trading.setEmergencyStop, { active: true })).rejects.toThrow(
      /Not authenticated/,
    );
    await expect(t.mutation(api.arise.trading.resetAccount, {})).rejects.toThrow(/Not authenticated/);
  });

  it("cannot read the platform event log", async () => {
    const t = newBackend();
    await expect(t.query(api.arise.system.list, { limit: 5 })).rejects.toThrow(/Not authenticated/);
  });

  it("cannot read monitor status", async () => {
    const t = newBackend();
    await expect(t.query(api.arise.monitor.adminStatus, {})).rejects.toThrow(/Not authenticated/);
  });

  it("cannot call the market-data proxy", async () => {
    const t = newBackend();
    await expect(t.action(api.arise.charts.candles, { symbol: "BTCUSDT", interval: "1h" })).rejects.toThrow(
      /Not authenticated/,
    );
  });

  it("gets empty (not shared) user-scoped reads", async () => {
    const t = newBackend();
    const userId = await seedUser(t);
    const owner = t.withIdentity({ subject: userId });
    await owner.mutation(api.arise.trading.createAccount, {});

    // Same backend, no identity: must not observe the seeded account.
    await expect(t.query(api.arise.trading.myAccount, {})).resolves.toBeNull();
    await expect(t.query(api.arise.trading.openPositions, {})).resolves.toEqual([]);
    await expect(t.query(api.arise.decisions.list, { limit: 10 })).resolves.toEqual([]);
  });
});

describe("cross-user isolation", () => {
  it("does not expose another user's paper account", async () => {
    const t = newBackend();
    const userA = await seedUser(t, { email: "a@example.com" });
    const userB = await seedUser(t, { email: "b@example.com" });
    await t.withIdentity({ subject: userA }).mutation(api.arise.trading.createAccount, {});

    const asA = await t.withIdentity({ subject: userA }).query(api.arise.trading.myAccount, {});
    const asB = await t.withIdentity({ subject: userB }).query(api.arise.trading.myAccount, {});
    expect(asA).not.toBeNull();
    expect(asB).toBeNull();
  });

  it("refuses a close request for another user's position", async () => {
    const t = newBackend();
    const userA = await seedUser(t, { email: "a@example.com" });
    const userB = await seedUser(t, { email: "b@example.com" });
    await t.withIdentity({ subject: userA }).mutation(api.arise.trading.createAccount, {});

    const positionId = await t.run(async (ctx) => {
      const decisionId = await ctx.db.insert("decisions", {
        userId: userA,
        symbol: "BTCUSDT",
        interval: "1h",
        mode: "paper" as const,
        status: "TRADE",
        direction: "LONG",
        confidence: 60,
        regime: "TREND",
        thesis: "seed",
        recommendedAction: "ENTER_LONG",
        dataQuality: "valid",
        dataAgeSec: 1,
        dataSource: "test",
        dataTimestamp: Date.now(),
        mind: {},
        agents: {},
      });
      return await ctx.db.insert("positions", {
        userId: userA,
        decisionId,
        symbol: "BTCUSDT",
        side: "LONG",
        qty: 1,
        entryPrice: 100,
        stopLoss: 95,
        takeProfit: 110,
        entryFee: 0.04,
        status: "OPEN",
        openedAt: Date.now(),
      });
    });

    await expect(
      t
        .withIdentity({ subject: userB })
        .mutation(api.arise.trading.closePosition, { positionId, price: 100, priceTime: Date.now() }),
    ).rejects.toThrow(/Not found/);

    // A's position is untouched and B owns nothing.
    const stillOpen = await t.withIdentity({ subject: userA }).query(api.arise.trading.openPositions, {});
    expect(stillOpen).toHaveLength(1);
  });

  it("does not reveal another user's decision by id", async () => {
    const t = newBackend();
    const userA = await seedUser(t, { email: "a@example.com" });
    const userB = await seedUser(t, { email: "b@example.com" });
    const decisionId = await t.run(async (ctx) =>
      ctx.db.insert("decisions", {
        userId: userA,
        symbol: "BTCUSDT",
        interval: "1h",
        mode: "paper" as const,
        status: "TRADE",
        direction: "LONG",
        confidence: 60,
        regime: "TREND",
        thesis: "seed",
        recommendedAction: "ENTER_LONG",
        dataQuality: "valid",
        dataAgeSec: 1,
        dataSource: "test",
        dataTimestamp: Date.now(),
        mind: {},
        agents: {},
      }),
    );

    await expect(
      t.withIdentity({ subject: userB }).query(api.arise.decisions.byId, { id: decisionId }),
    ).resolves.toBeNull();
    await expect(
      t.withIdentity({ subject: userA }).query(api.arise.decisions.byId, { id: decisionId }),
    ).resolves.not.toBeNull();
  });

  it("hides execution + billing detail from non-admins but keeps the audit trail", async () => {
    const t = newBackend();
    const user = await seedUser(t);
    await t.run(async (ctx) => {
      await ctx.db.insert("systemEvents", {
        level: "INFO", area: "EXECUTION", code: "MONITOR_EXIT_STOP_LOSS",
        message: "position=secret symbol=BTCUSDT qty=3 pnl=-12.5", at: Date.now(),
      });
      await ctx.db.insert("systemEvents", {
        level: "WARN", area: "DATA", code: "PROVIDER_FAILURE",
        message: "BTCUSDT: provider timeout", at: Date.now(),
      });
    });

    const asUser = await t.withIdentity({ subject: user }).query(api.arise.system.list, { limit: 10 });
    const exec = asUser.find((e) => e.area === "EXECUTION");
    const data = asUser.find((e) => e.area === "DATA");
    expect(exec?.message).not.toContain("pnl=-12.5");
    expect(data?.message).toContain("provider timeout");
  });
});

describe("admin authorization + first-admin bootstrap", () => {
  it("refuses admin-only reads for non-admins", async () => {
    const t = newBackend();
    const user = await seedUser(t);
    await expect(
      t.withIdentity({ subject: user }).query(api.arise.billingFunctions.adminUsers, {}),
    ).rejects.toThrow(/Forbidden: admin only/);
  });

  it("allows admin-only reads for admins", async () => {
    const t = newBackend();
    const admin = await seedUser(t, { email: "root@example.com", role: "admin" });
    await expect(
      t.withIdentity({ subject: admin }).query(api.arise.billingFunctions.adminUsers, {}),
    ).resolves.toBeInstanceOf(Array);
  });

  it("fails closed when no bootstrap code is configured", async () => {
    const t = newBackend();
    const user = await seedUser(t);
    await expect(
      t.withIdentity({ subject: user }).mutation(api.arise.billingFunctions.bootstrapAdmin, { code: "x" }),
    ).rejects.toThrow(/ARISE_ADMIN_CODE/);
  });

  it("rejects a wrong bootstrap code", async () => {
    process.env.ARISE_ADMIN_CODE = "correct-code";
    const t = newBackend();
    const user = await seedUser(t);
    await expect(
      t.withIdentity({ subject: user }).mutation(api.arise.billingFunctions.bootstrapAdmin, { code: "nope" }),
    ).rejects.toThrow(/Invalid setup code/);
  });

  it("can be claimed exactly once, and not reused after initialization", async () => {
    process.env.ARISE_ADMIN_CODE = "correct-code";
    const t = newBackend();
    const first = await seedUser(t, { email: "first@example.com" });
    const second = await seedUser(t, { email: "second@example.com" });

    await t.withIdentity({ subject: first }).mutation(api.arise.billingFunctions.bootstrapAdmin, {
      code: "correct-code",
    });
    // A second claim is refused by the one-time closure marker. (The message is asserted
    // exactly because the refusal now comes from bootstrap being permanently closed
    // rather than merely from an admin existing — see the replay test below.)
    await expect(
      t.withIdentity({ subject: second }).mutation(api.arise.billingFunctions.bootstrapAdmin, {
        code: "correct-code",
      }),
    ).rejects.toThrow(/bootstrap is already closed/i);

    const admins = await t.run(async (ctx) => {
      const rows = await ctx.db.query("users").collect();
      return rows.filter((u) => u.role === "admin");
    });
    expect(admins).toHaveLength(1);
    expect(admins[0].email).toBe("first@example.com");

    // The closure is persisted, not inferred from the absence of a request.
    const marked = await t.run(async (ctx) => ctx.db.query("bootstrapState").collect());
    expect(marked).toHaveLength(1);
    expect(marked[0].completedBy).toBe(first);
  });

  it("cannot be re-opened by deleting every administrator and replaying the code", async () => {
    process.env.ARISE_ADMIN_CODE = "correct-code";
    const t = newBackend();
    const first = await seedUser(t, { email: "first@example.com" });
    const attacker = await seedUser(t, { email: "later@example.com" });

    await t
      .withIdentity({ subject: first })
      .mutation(api.arise.billingFunctions.bootstrapAdmin, { code: "correct-code" });

    // Remove every administrator: a naive "is there an admin?" check would re-open here.
    await t.run(async (ctx) => {
      for (const u of await ctx.db.query("users").collect()) {
        if (u.role === "admin") await ctx.db.patch(u._id, { role: undefined });
      }
    });

    await expect(
      t
        .withIdentity({ subject: attacker })
        .mutation(api.arise.billingFunctions.bootstrapAdmin, { code: "correct-code" }),
    ).rejects.toThrow(/bootstrap is already closed/i);

    const admins = await t.run(async (ctx) =>
      (await ctx.db.query("users").collect()).filter((u) => u.role === "admin"),
    );
    expect(admins).toHaveLength(0); // still nobody: the grant never happened
  });

  it("cannot be claimed by competing concurrent requests", async () => {
    process.env.ARISE_ADMIN_CODE = "correct-code";
    const t = newBackend();
    const a = await seedUser(t, { email: "a@example.com" });
    const b = await seedUser(t, { email: "b@example.com" });

    const results = await Promise.allSettled([
      t.withIdentity({ subject: a }).mutation(api.arise.billingFunctions.bootstrapAdmin, { code: "correct-code" }),
      t.withIdentity({ subject: b }).mutation(api.arise.billingFunctions.bootstrapAdmin, { code: "correct-code" }),
    ]);
    expect(results.filter((r) => r.status === "fulfilled")).toHaveLength(1);

    const admins = await t.run(async (ctx) => {
      const rows = await ctx.db.query("users").collect();
      return rows.filter((u) => u.role === "admin");
    });
    expect(admins).toHaveLength(1);
  });
});

describe("market-data proxy input validation", () => {
  it("rejects an unsupported interval before contacting a provider", async () => {
    const t = newBackend();
    const user = await seedUser(t);
    await expect(
      t.withIdentity({ subject: user }).action(api.arise.charts.candles, {
        symbol: "BTCUSDT",
        interval: "3s",
      }),
    ).rejects.toThrow(/unsupported interval/);
  });

  it("rejects an unsupported symbol", async () => {
    const t = newBackend();
    const user = await seedUser(t);
    await expect(
      t.withIdentity({ subject: user }).action(api.arise.charts.candles, {
        symbol: "DOGEUSDT",
        interval: "1h",
      }),
    ).rejects.toThrow(/unsupported symbol/);
  });

  it("rejects a non-positive or non-finite limit", async () => {
    const t = newBackend();
    const user = await seedUser(t);
    for (const limit of [0, -5, Number.NaN]) {
      await expect(
        t.withIdentity({ subject: user }).action(api.arise.charts.candles, {
          symbol: "BTCUSDT",
          interval: "1h",
          limit,
        }),
      ).rejects.toThrow(/limit must be a positive number/);
    }
  });
});
