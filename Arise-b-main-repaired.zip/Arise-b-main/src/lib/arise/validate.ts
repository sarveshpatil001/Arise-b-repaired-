// ARISE V1 — market data validation. Fail-closed: bad data ⇒ invalid ⇒ NO TRADE.
// Checks per PRD §10: missing/duplicate/invalid prices, impossible OHLC, staleness,
// gaps, monotonic time ordering.

import type { AriseConfig } from "./config";
import type { Bar, DataQuality } from "./types";
import { stdev } from "./math";
import { intervalMs } from "./quant";

export interface RawBar {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface ValidationResult {
  bars: Bar[];
  quality: DataQuality;
  notes: string[];
  duplicateCount: number;
  gapCount: number;
  removedCount: number;
}

const isPosNum = (v: unknown): v is number =>
  typeof v === "number" && Number.isFinite(v) && v > 0;

export function validateBars(
  raw: RawBar[],
  opts: {
    symbol: string;
    assetClass: Bar["assetClass"];
    interval: string;
    now: number; // ms epoch UTC
    config: AriseConfig;
  },
): ValidationResult {
  const { symbol, assetClass, interval } = opts;
  const notes: string[] = [];
  const step = intervalMs(interval);
  const sorted = [...raw].sort((a, b) => a.time - b.time);

  // Deduplicate by timestamp (duplicate event protection)
  const seen = new Set<number>();
  let duplicateCount = 0;
  const unique: RawBar[] = [];
  for (const b of sorted) {
    if (seen.has(b.time)) {
      duplicateCount++;
      continue;
    }
    seen.add(b.time);
    unique.push(b);
  }
  if (duplicateCount > 0) notes.push(`${duplicateCount} duplicate bar(s) removed`);

  // Structural validity
  const valid: RawBar[] = [];
  let removedCount = 0;
  for (const b of unique) {
    const okShape =
      isPosNum(b.time) &&
      isPosNum(b.open) &&
      isPosNum(b.high) &&
      isPosNum(b.low) &&
      isPosNum(b.close) &&
      b.high >= b.low &&
      b.high >= Math.max(b.open, b.close) - 1e-9 &&
      b.low <= Math.min(b.open, b.close) + 1e-9 &&
      b.volume >= 0;
    if (!okShape) {
      removedCount++;
      continue;
    }
    valid.push(b);
  }
  if (removedCount > 0) notes.push(`${removedCount} structurally invalid bar(s) removed`);

  // Detect gaps
  let gapCount = 0;
  for (let i = 1; i < valid.length; i++) {
    if (valid[i].time - valid[i - 1].time > step * 1.5) gapCount++;
  }
  if (gapCount > 0) notes.push(`${gapCount} data gap(s) detected`);

  // Statistical outlier scan (z-score of returns on closes)
  const closes = valid.map((b) => b.close);
  const rets: number[] = [];
  for (let i = 1; i < closes.length; i++) {
    rets.push((closes[i] - closes[i - 1]) / closes[i - 1]);
  }
  const sd = stdev(rets);
  let outliers = 0;
  for (const r of rets) {
    if (sd > 0 && Math.abs(r / sd) > 8) outliers++;
  }
  if (outliers > 0) notes.push(`${outliers} statistical outlier return(s) >8σ`);

  const quality: DataQuality = removedCount > 0 ? "degraded" : "valid";
  const bars: Bar[] = valid.map((b) => ({
    symbol,
    assetClass,
    interval,
    time: b.time,
    open: b.open,
    high: b.high,
    low: b.low,
    close: b.close,
    volume: b.volume,
    source: opts.symbol.includes("USDT") ? "binance" : "yahoo",
    quality,
  }));

  return { bars, quality, notes, duplicateCount, gapCount, removedCount };
}

/** Assesses freshness of a validated set of bars + optional top-of-book. */
export function assessFreshness(
  bars: Bar[],
  opts: {
    interval: string;
    now: number;
    config: AriseConfig;
    bestBid?: number | null;
    bestAsk?: number | null;
  },
): { quality: DataQuality; quoteAgeSec: number; notes: string[] } {
  const notes: string[] = [];
  const last = bars[bars.length - 1];
  if (!last) return { quality: "invalid", quoteAgeSec: Infinity, notes: ["no bars"] };
  const step = intervalMs(opts.interval) / 1000;
  const barAgeSec = (opts.now - last.time) / 1000;
  const quoteAgeSec = barAgeSec;
  const notes2: string[] = notes;

  if (barAgeSec > step * opts.config.barStaleMultiplier) {
    notes2.push(`latest bar is ${Math.round(barAgeSec / 60)}m old (>${opts.config.barStaleMultiplier}× interval)`);
    return { quality: "stale", quoteAgeSec, notes: notes2 };
  }
  if (bars.length < opts.config.minBars) {
    notes2.push(`only ${bars.length} validated bars (< ${opts.config.minBars})`);
    return { quality: "degraded", quoteAgeSec, notes: notes2 };
  }
  // Bid/ask sanity if present
  if (
    opts.bestBid != null &&
    opts.bestAsk != null &&
    (opts.bestBid <= 0 || opts.bestAsk <= 0 || opts.bestAsk < opts.bestBid)
  ) {
    notes2.push("crossed/invalid top-of-book");
    return { quality: "invalid", quoteAgeSec, notes: notes2 };
  }
  return { quality: "valid", quoteAgeSec, notes: notes2 };
}
