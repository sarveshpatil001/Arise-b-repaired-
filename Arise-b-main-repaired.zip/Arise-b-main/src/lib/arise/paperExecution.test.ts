// ARISE V1 — PAPER EXECUTION + MONITOR COVERAGE regression tests (PRD Step 6).
// Runs the real Convex functions in an in-memory backend:
//   - duplicate/concurrent executions cannot open a second position or debit a
//     second fee (durable idempotency, not the broker's per-instance Set),
//   - a manual close must be priced from a real fresh 5m bar and can only be
//     applied once (no duplicate exits, no corrupted balance),
//   - the monitor reaches every OPEN position, not just the first 25.
// No network, no live prices, no real orders.

import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import schema from "@/convex/schema";
import { api, internal } from "@/convex/_generated/api";
import type { Id } from "@/convex/_generated/dataModel";

const modules = import.meta.glob("../../convex/**/*.ts");
const MIN = 60_000;

type TestConvex = ReturnType<typeof convexTest>;

function newBackend() {
  return convexTest(schema, modules);
}

/** Fresh completed 15m mark — what the paper ledger requires to mark equity. */
function mark(symbol: string, price: number) {
  return { symbol, price, time: Date.now() - MIN, interval: "15m", completed: true };
}

async function seedTrader(t: TestConvex, balance = 10_000) {
  const userId = await t.run(async (ctx) => {
    const id = await ctx.db.insert("users", { email: "trader@example.com" });
    await ctx.db.insert("paperAccounts", {
      userId: id,
      balance,
      equityHighWaterMark: balance,
      dayStartEquity: balance,
      dayKey: new Date().toISOString().slice(0, 10),
      emergencyStop: false,
      startingBalance: balance,
    });
    return id;
  });
  return userId;
}

function seedDecision(t: TestConvex, userId: Id<"users">) {
  return t.run(async (ctx) =>
    ctx.db.insert("decisions", {
      userId,
      symbol: "BTCUSDT",
      interval: "1h",
      mode: "paper" as const,
      status: "TRADE",
      direction: "LONG",
      confidence: 60,
      regime: "TREND",
      thesis: "seed",
      recommendedAction: "ENTER_LONG",
      dataQuality: "valid",
      dataAgeSec: 1,
      dataSource: "test",
      dataTimestamp: Date.now(),
      mind: {},
      agents: {},
    }),
  );
}

/** Opens a paper position through the real internal mutation. */
async function open(
  t: TestConvex,
  userId: Id<"users">,
  decisionId: Id<"decisions">,
  idemKey?: string,
) {
  return await t.mutation(internal.arise.trading.openPosition, {
    userId,
    decisionId,
    symbol: "BTCUSDT",
    side: "LONG",
    qty: 1,
    entryPrice: 100,
    stopLoss: 95,
    takeProfit: 110,
    entryFee: 0.04,
    maxLossQuote: 5,
    thesis: "test",
    riskDecision: "ALL_CHECKS_PASS",
    marks: [mark("BTCUSDT", 100)],
    idemKey,
  });
}

async function openCount(t: TestConvex) {
  return await t.run(async (ctx) => (await ctx.db.query("positions").collect()).length);
}

async function balanceOf(t: TestConvex, userId: Id<"users">) {
  // `.filter` (not `.withIndex`) because convex-test types the raw ctx against
  // its own index map.
  const account = await t.run(async (ctx) =>
    ctx.db
      .query("paperAccounts")
      .filter((q) => q.eq(q.field("userId"), userId))
      .first(),
  );
  return account?.balance ?? null;
}

describe("durable execution idempotency", () => {
  it("opens one position for a repeated execution key", async () => {
    const t = newBackend();
    const userId = await seedTrader(t);
    const decisionId = await seedDecision(t, userId);

    const first = await open(t, userId, decisionId, "p:u:BTCUSDT:1h:1000");
    const second = await open(t, userId, decisionId, "p:u:BTCUSDT:1h:1000");

    expect(first.duplicate).toBe(false);
    expect(second.duplicate).toBe(true);
    expect(await openCount(t)).toBe(1);
    // The entry fee was debited exactly once.
    expect(await balanceOf(t, userId)).toBeCloseTo(10_000 - 0.04, 6);
  });

  it("still opens a position for a different candle", async () => {
    const t = newBackend();
    const userId = await seedTrader(t);
    const decisionId = await seedDecision(t, userId);

    await open(t, userId, decisionId, "p:u:BTCUSDT:1h:1000");
    await open(t, userId, decisionId, "p:u:BTCUSDT:1h:2000");

    expect(await openCount(t)).toBe(2);
  });

  it("does not open twice when duplicating the request", async () => {
    const t = newBackend();
    const userId = await seedTrader(t);
    const decisionId = await seedDecision(t, userId);

    // A retry storm: five identical executions (one bar) must never stack up.
    for (let i = 0; i < 5; i++) {
      await open(t, userId, decisionId, "same-key");
    }
    expect(await openCount(t)).toBe(1);
    expect(await balanceOf(t, userId)).toBeCloseTo(10_000 - 0.04, 6);
  });

  it("rejects a duplicate even when the broker instance is new each time", async () => {
    // Regression guard for the original defect: the broker's in-memory key set is
    // rebuilt per request, so only the database can catch this.
    const t = newBackend();
    const userId = await seedTrader(t);
    const decisionId = await seedDecision(t, userId);
    await open(t, userId, decisionId, "durable-key");
    const before = await balanceOf(t, userId);
    await open(t, userId, decisionId, "durable-key");
    expect(await balanceOf(t, userId)).toBe(before);
  });
});

describe("manual close integrity", () => {
  it("refuses a close price that has no real bar", async () => {
    const t = newBackend();
    const userId = await seedTrader(t);
    const decisionId = await seedDecision(t, userId);
    const opened = await open(t, userId, decisionId, "k1");

    await expect(
      t
        .withIdentity({ subject: userId })
        .mutation(api.arise.trading.closePosition, {
          positionId: opened.positionId,
          price: 1_000_000,
          priceTime: 0,
        }),
    ).rejects.toThrow(/INVALID_CLOSE_PRICE/);
    expect(await openCount(t)).toBe(1);
  });

  it("refuses a stale close price", async () => {
    const t = newBackend();
    const userId = await seedTrader(t);
    const decisionId = await seedDecision(t, userId);
    const opened = await open(t, userId, decisionId, "k2");

    await expect(
      t
        .withIdentity({ subject: userId })
        .mutation(api.arise.trading.closePosition, {
          positionId: opened.positionId,
          price: 100,
          priceTime: Date.now() - 30 * MIN,
        }),
    ).rejects.toThrow(/INVALID_CLOSE_PRICE/);
  });

  it("closes once at a valid fresh price and cannot be replayed", async () => {
    const t = newBackend();
    const userId = await seedTrader(t);
    const decisionId = await seedDecision(t, userId);
    const opened = await open(t, userId, decisionId, "k3");
    const before = await balanceOf(t, userId);

    const priceTime = Date.now() - 2 * MIN;
    await t
      .withIdentity({ subject: userId })
      .mutation(api.arise.trading.closePosition, { positionId: opened.positionId, price: 110, priceTime });

    // LONG 100 -> 110, qty 1, entry fee 0.04 + exit fee 4 bps of 110 = 0.044
    const expected = (before ?? 0) + (110 - 100) - 0.044;
    expect(await balanceOf(t, userId)).toBeCloseTo(expected, 6);

    // Replaying the close must not credit the balance a second time.
    await expect(
      t
        .withIdentity({ subject: userId })
        .mutation(api.arise.trading.closePosition, { positionId: opened.positionId, price: 110, priceTime }),
    ).rejects.toThrow(/Position not open/);
    expect(await balanceOf(t, userId)).toBeCloseTo(expected, 6);
  });
});

describe("monitor coverage beyond one batch", () => {
  async function seedMany(t: TestConvex, count: number) {
    const userId = await seedTrader(t);
    const decisionId = await seedDecision(t, userId);
    await t.run(async (ctx) => {
      for (let i = 0; i < count; i++) {
        await ctx.db.insert("positions", {
          userId,
          decisionId,
          symbol: "BTCUSDT",
          side: "LONG",
          qty: 1,
          entryPrice: 100,
          stopLoss: 95,
          takeProfit: 110,
          entryFee: 0.04,
          status: "OPEN",
          openedAt: Date.now(),
        });
      }
    });
    return userId;
  }

  it("reaches every open position across pages (not just the first 25)", async () => {
    const t = newBackend();
    await seedMany(t, 30);

    const page1 = await t.query(internal.arise.monitor.openPositionsBatch, {});
    expect(page1.positions).toHaveLength(25);
    expect(page1.isDone).toBe(false);

    const page2 = await t.query(internal.arise.monitor.openPositionsBatch, {
      cursor: page1.continueCursor,
    });
    const seen = new Set([...page1.positions, ...page2.positions].map((p) => p._id));
    expect(seen.size).toBe(30);
    expect(page2.isDone).toBe(true);
  });

  it("handles a single page without wrapping", async () => {
    const t = newBackend();
    await seedMany(t, 4);
    const page = await t.query(internal.arise.monitor.openPositionsBatch, {});
    expect(page.positions).toHaveLength(4);
    expect(page.isDone).toBe(true);
  });

  it("persists the scan cursor so the next tick continues forward", async () => {
    const t = newBackend();
    await seedMany(t, 30);
    const page1 = await t.query(internal.arise.monitor.openPositionsBatch, {});

    // First run claims the monitor (creates the state row).
    const first = await t.mutation(internal.arise.monitor.claimRun, { at: Date.now() });
    expect(first.decision).toBe("go");
    expect(first.cursor).toBeUndefined();

    await t.mutation(internal.arise.monitor.saveOpenCursor, { cursor: page1.continueCursor });

    // A later run (past the 5 minute lease) resumes where the scan stopped.
    const later = await t.mutation(internal.arise.monitor.claimRun, {
      at: Date.now() + 6 * MIN,
    });
    expect(later.decision).toBe("go");
    expect(later.cursor).toBe(page1.continueCursor);
  });

  it("never processes a closed position twice", async () => {
    const t = newBackend();
    const userId = await seedTrader(t);
    const decisionId = await seedDecision(t, userId);
    const opened = await open(t, userId, decisionId, "closed-once");

    await t
      .withIdentity({ subject: userId })
      .mutation(api.arise.trading.closePosition, {
        positionId: opened.positionId,
        price: 105,
        priceTime: Date.now() - 2 * MIN,
      });

    const batch = await t.query(internal.arise.monitor.openPositionsBatch, {});
    expect(batch.positions).toHaveLength(0);
  });
});
